package com.ems.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.project.entity.Employee;
import com.ems.project.repository.EmployeeRepositoryy;

// import java.util.List;

// import com.ems.project.entity.Employee;
// import com.ems.project.model.EmployeeDTO;
@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepositoryy repo;

    public void addEmployee(Employee e) {
        repo.save(e);
    }
    // EmployeeDTO createEmployee(Employee employee);

    // List<EmployeeDTO> getAllEmployee();

    // EmployeeDTO getEmployeeById(int id);

    // EmployeeDTO updateEmployee(int id, Employee employee);

    // String deleteEmployee(int id);

}
