package com.ems.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ems.project.entity.Employee;

public interface EmployeeRepositoryy extends JpaRepository<Employee, Integer> {

}
