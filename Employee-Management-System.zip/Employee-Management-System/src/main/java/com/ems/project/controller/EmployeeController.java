package com.ems.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

// import java.util.List;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;

// import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.ModelAttribute;
// import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.PutMapping;
// import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ems.project.entity.Employee;
// import com.ems.project.model.EmployeeDTO;
// import com.ems.project.service.EmployeeService;
// import com.ems.project.util.Converter;
import com.ems.project.service.EmployeeService;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService service;

    @GetMapping("/index")
    public String home() {
        return "index";
    }

    @GetMapping("/empAdd")
    public String empAddForm() {
        return "emp-add";
    }

    /**
     * @param e
     * @return
     */
    @PostMapping("/register")
    public String employeeRegister(@ModelAttribute Employee e) {
        System.out.println(e);
        service.addEmployee(e);
        return "redirect:/";
    }
}

//////////////////////////////////////////////////////////////////////////////

// @Autowired
// private EmployeeService employeeService;
// @Autowired
// private Converter converter;

// // @PostMapping("/api/createEmployee")
// // Employee createEmployee(@RequestBody Employee employee)
// // {
// // return EmployeeService.createEmployee(employee);
// // }
// @PostMapping("/api/createEmployee")
// ResponseEntity<EmployeeDTO> createEmployee(@RequestBody EmployeeDTO
// employeeDTO) {
// final Employee employee = converter.convertToEmployeeEntity(employeeDTO);
// return new
// ResponseEntity<EmployeeDTO>(employeeService.createEmployee(employee),
// HttpStatus.CREATED);
// }

// @GetMapping("/api/getAllEmployee")
// List<EmployeeDTO> getAllEmployee() {
// return employeeService.getAllEmployee();
// }

// @GetMapping("/api/getEmployeeById/{id}")
// EmployeeDTO getEmployeeById(@PathVariable int id) {
// return employeeService.getEmployeeById(id);
// }

// @PutMapping("/api/updateEmployee/{id}")
// EmployeeDTO updateEmployee(@PathVariable int id, @RequestBody EmployeeDTO
// employeeDTO) {
// final Employee employee = converter.convertToEmployeeEntity(employeeDTO);
// return employeeService.updateEmployee(id, employee);
// }

// @DeleteMapping("/api/deleteEmployee/{id}")
// String deleteEmployee(@PathVariable int id) {
// return employeeService.deleteEmployee(id);
// }
// }
