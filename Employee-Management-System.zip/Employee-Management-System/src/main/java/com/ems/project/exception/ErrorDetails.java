package com.ems.project.exception;

public class ErrorDetails {

}
