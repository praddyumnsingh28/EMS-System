package com.ems.project.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeDTO {

    private int id;

    private String name;

    private String mob;
}
