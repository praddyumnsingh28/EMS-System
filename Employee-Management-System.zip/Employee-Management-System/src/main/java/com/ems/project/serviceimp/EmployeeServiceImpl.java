// package com.ems.project.serviceimp;

// import java.util.ArrayList;
// import java.util.List;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;

// import com.ems.project.entity.Employee;
// import com.ems.project.model.EmployeeDTO;
// import com.ems.project.repository.EmployeeRepositoryy;
// import com.ems.project.service.EmployeeService;
// import com.ems.project.util.Converter;

// @Service
// public class EmployeeServiceImpl implements EmployeeService {
// @Autowired
// private EmployeeRepositoryy employeeRepository;
// @Autowired
// private Converter converter;

// public EmployeeDTO createStudent(Employee employee) {
// Employee emp = employeeRepository.save(employee);
// return converter.convertToEmployeeDTO(emp);

// }

// @Override
// public List<EmployeeDTO> getAllEmployee() {

// List<Employee> employees = employeeRepository.findAll();
// // List of type DTO
// List<EmployeeDTO> dtoList = new ArrayList<>();
// for (Employee e : employees) {
// dtoList.add(converter.convertToEmployeeDTO(e));
// }
// return dtoList;
// }

// @Override
// public EmployeeDTO getEmployeeById(int id) {
// Employee s = employeeRepository.findById(id).get();

// return converter.convertToEmployeeDTO(s);
// }

// @Override
// public EmployeeDTO updateEmployee(int id, Employee employee) {
// Employee e = employeeRepository.findById(id).get();
// e.setName(employee.getName());
// e.setSalary(employee.getSalary());
// e.setAddress(employee.getAddress());
// e.setEmail(employee.getEmail());
// e.setMob(employee.getMob());
// Employee emp = employeeRepository.save(e);
// return converter.convertToEmployeeDTO(emp);
// }

// @Override
// public String deleteEmployee(int id) {
// employeeRepository.deleteById(id);
// return "employee got deleted successfully!!!";
// }

// @Override
// public EmployeeDTO createEmployee(Employee employee) {

// throw new UnsupportedOperationException("Unimplemented method
// 'createEmployee'");
// }
// }
