package com.ems.project.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.ems.project.entity.Employee;
import com.ems.project.model.EmployeeDTO;

@Component
public class Converter {
    // convert from DTO to entity
    public Employee convertToEmployeeEntity(EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        if (employeeDTO != null) {
            BeanUtils.copyProperties(employeeDTO, employee);
        }
        return employee;
    }

    // convert from Entity to DTO
    public EmployeeDTO convertToEmployeeDTO(Employee employee) {
        EmployeeDTO employeeDTO = new EmployeeDTO();
        if (employee != null) {
            BeanUtils.copyProperties(employee, employeeDTO);
        }
        return employeeDTO;
    }
}
